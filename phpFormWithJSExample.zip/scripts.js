function saveFormData() {
	
	// get the data using the input ids
	var name = document.getElementById('name').value;
	var message = document.getElementById('message').value;
	
	// set up the ajax request to update the database
	// ajax = 'asynchronous javascript and xml'
	xmlHttpSaveFormData = new XMLHttpRequest()
        if (xmlHttpSaveFormData == null) {
                alert ("Browser does not support HTTP Request")
                return
        }

        var params = 'name=' + escape(name);
        params += "&message=" + escape(message);
        var url = 'saveFormData.php'

        xmlHttpSaveFormData.open("POST", url, true);
        xmlHttpSaveFormData.setRequestHeader("Content-type",
        	"application/x-www-form-urlencoded");
        xmlHttpSaveFormData.send(params);
        
        // update the display
        var display = "<h3>Thanks, " + name + "!</h3> We've received your message. ";
        display += "For your convenience, your message is displayed below.<br /><br />";
        display += "<b>Message:</b><br />";
        display += '<span id="formMessage">' + message + '</span>';
        
        var element = document.getElementById('formOutputDisplay');
        element.innerHTML = display;
}

