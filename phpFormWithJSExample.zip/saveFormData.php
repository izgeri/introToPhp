<?php 

require("conn.php");

$name = $_POST['name'];
$message = $_POST['message'];

$query = "INSERT INTO formData
	(name, message)
	VALUES ('" . $mysqli->real_escape_string($name) . "',
		'" . $mysqli->real_escape_string($message) . "')";
$result = $mysqli->query($query);

if (!$result) {
	$dbError = "ERROR: Message not recorded: " . $mysqli->error;
}

?>

