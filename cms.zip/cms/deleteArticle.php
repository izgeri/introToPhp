<?php

// include the db connection info and the article class
require( "conn.php" );
require("classes/class.article.php");

$articleId = $_POST['articleId'];

$articleObject = new article($mysqli);
$articleObject->deleteArticle($articleId);

?>
