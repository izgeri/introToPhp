<?php

require( "conn.php" );
require("classes/class.article.php");

if ( !isset($_GET["articleId"]) || !$_GET["articleId"] ) {
	
	$pageContent = '<p><em>Article not found.</em></p>';
	
} else {

	$articleObject = new article($mysqli);

	$articleInfoArray = $articleObject->getArticle( (int)$_GET["articleId"] );
	
	$articleTitle = $articleInfoArray['title'];
	$articleSummary = $articleInfoArray['summary'];
	$articleContent = $articleInfoArray['content'];
	$articleDate = $articleInfoArray['publicationDate'];
	
	$pageContent = '<h1 style="width: 75%;">' . htmlspecialchars($articleTitle) . '</h1>';
	$pageContent .= '<div style="width: 75%; font-style: italic;">' . htmlspecialchars($articleInfoArray['summary']) . '</div>';
	$pageContent .= '<div style="width: 75%;">' . $articleInfoArray['content'] . '</div>';
	$pageContent .= '<p class="pubDate">Published on ' . date('j F Y', strtotime($articleInfoArray['publicationDate'])) . '</p>';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  
	<title><?php echo htmlspecialchars($articleTitle); ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
    
</head>
<body>
  
	<div id="container">

	<a href="."><img id="logo" src="images/logo.jpg" alt="My CMS" /></a>
      
	<?php echo $pageContent; ?>

	<p><a href="index.php">Return to Homepage</a></p>

	<p><a href="archive.php">Article Archive</a></p>
      
	<div id="footer">
		My CMS &copy; 2016. All rights reserved. <a href="admin.php">Site Admin</a>
	</div>

	</div>
</body>
</html>  
