<?php

require( "conn.php" );
require("classes/class.article.php");

$username = isset( $_COOKIE['username'] ) ? $_COOKIE['username'] : "";
if (!$username) {
	header("Refresh: 0; URL=login.php");
	echo "You must be logged in to do that.<br>";
	echo "You are being redirected to the login page.<br>";
	echo "If you're not there in 5 seconds, " .
			"<a href=\"login.php\">click here</a>";
	die();
}

if ( !isset($_GET["articleId"]) || !$_GET["articleId"] ) {
	
	$pageTitle = 'New Article';
	$articleTitle = '';
	$articleSummary = '';
	$articleContent = '';
	$articleDate = date('Y-m-d');
	$articleId = '';
	
} else {

	$articleId = $_GET['articleId'];
	$pageTitle = 'Edit Article';
	
	$articleObject = new article($mysqli);
	$articleInfoArray = $articleObject->getArticle((int)$articleId);
	
	$articleTitle = $articleInfoArray['title'];
	$articleSummary = $articleInfoArray['summary'];
	$articleContent = $articleInfoArray['content'];
	$articleDate = $articleInfoArray['publicationDate'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  
	<title><?php echo htmlspecialchars($articleTitle); ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<script src="js/scripts.js" type="text/javascript"></script>

</head>
<body>
  
	<div id="container">

	<a href="."><img id="logo" src="images/logo.jpg" alt="My CMS" /></a>
      
	<div id="adminHeader">
        <h2>My CMS Admin</h2>
        <p>You are logged in as <b><?php echo htmlspecialchars( $_COOKIE['username']) ?></b>. <a onclick="logout();">Log out</a></p>
      </div>

      <h1><?php echo $pageTitle; ?></h1>

        <ul>

          <li>
            <label for="title">Article Title</label>
            <input type="text" name="title" id="title" placeholder="Name of the article" required autofocus maxlength="255" value="<?php echo htmlspecialchars( $articleTitle ); ?>" />
          </li>

          <li>
            <label for="summary">Article Summary</label>
            <textarea name="summary" id="summary" placeholder="Brief description of the article" required maxlength="1000" style="height: 5em;"><?php echo htmlspecialchars( $articleSummary ); ?></textarea>
          </li>

          <li>
            <label for="content">Article Content</label>
            <textarea name="content" id="content" placeholder="The HTML content of the article" required maxlength="100000" style="height: 30em;"><?php echo htmlspecialchars( $articleContent ); ?></textarea>
          </li>

          <li>
            <label for="publicationDate">Publication Date</label>
            <input type="date" name="publicationDate" id="publicationDate" placeholder="YYYY-MM-DD" required maxlength="10" value="<?php echo $articleDate; ?>" />
	</li>


        </ul>
        
        <input type="hidden" id="articleId" value="<?php echo $articleId; ?>" />

        <div class="buttons">
          <input type="button" name="saveChanges" value="Save Changes" onclick="saveChanges();" />
	  <?php if ($articleId) { ?>
	    <input type="button" name="deleteArticle" value="Delete This Article" onclick="deleteArticle('<?php echo $articleId; ?>');" />
	  <?php } ?>
          <input type="button" name="cancel" value="Cancel" onclick="window.location.href='admin.php'" />
        </div>

	<div id="footer">
		My CMS &copy; 2016. All rights reserved. <a href="admin.php">Site Admin</a>
	</div>

	</div>
</body>
</html>  
