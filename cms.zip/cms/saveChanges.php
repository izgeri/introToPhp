<?php

// include the db connection info and the article class
require( "conn.php" );
require("classes/class.article.php");

$articleId = $_POST['articleId'];
$articleTitle = $_POST['articleTitle'];
$articleSummary = $_POST['articleSummary'];
$articleContent = $_POST['articleContent'];
$articleDate = $_POST['articleDate'];

$articleArray = array('articleId' => $articleId,
	'articleTitle' => $articleTitle,
	'articleSummary' => $articleSummary,
	'articleContent' => $articleContent,
	'articleDate' => $articleDate);

$articleObject = new article($mysqli);

if ($articleId != '') {
	$articleObject->updateArticle($articleArray);
} else {
	$articleObject->addArticle($articleArray);
}

?>
