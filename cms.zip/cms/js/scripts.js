function checkLogin() {
	
	// get the data using the input ids
	var username = document.getElementById('username').value;
	var password = document.getElementById('password').value;
	
	// set up the ajax request to update the database
	// ajax = 'asynchronous javascript and xml'
	xmlHttpLogin = new XMLHttpRequest()
        if (xmlHttpLogin == null) {
                alert ("Browser does not support HTTP Request")
                return
        }

        var params = 'username=' + escape(username);
        params += "&password=" + escape(password);
        var url = 'checkLogin.php'

        xmlHttpLogin.open("POST", url, true);
        xmlHttpLogin.setRequestHeader("Content-type",
        	"application/x-www-form-urlencoded");
        xmlHttpLogin.send(params);
        xmlHttpLogin.onreadystatechange = function() {
        	if(xmlHttpLogin.readyState === 4 || xmlHttpLogin.readyState == "complete") { // done
        		var success = xmlHttpLogin.responseText;
        		
        		if (success == 1) {
        			window.location.href = 'admin.php';
        		} else {
				var errorDiv = document.getElementById('loginErrorMessage');
				errorDiv.innerHTML = '<em>invalid username/password. please try again.</em>';
				errorDiv.style.visibility = 'visible';
        		}
        	}
        };
        
}

function logout() {

	var proceed = confirm('Are you sure you want to log out?');

	if (proceed) {

		window.location = 'logout.php';
	}
}

function deleteArticle(articleId) {

	var proceed = confirm('Are you sure you want to delete the article?');

	if (proceed) {

		var params = 'articleId=' + escape(articleId);
		var url = 'deleteArticle.php';

		xmlHttpDeleteArticle = new XMLHttpRequest()
		if (xmlHttpDeleteArticle == null) {
			alert("Browser does not support HTTP request");
			return;
		}

		xmlHttpDeleteArticle.open("POST", url, true);
		xmlHttpDeleteArticle.setRequestHeader("Content-type",
			"application/x-www-form-urlencoded");
		xmlHttpDeleteArticle.send(params);

		alert('The article has been deleted.')
		window.location.href = 'admin.php';
	}
}

function saveChanges() {

	var articleId = document.getElementById('articleId').value;
	var articleTitle = document.getElementById('title').value;
	var articleContent = document.getElementById('content').value;
	var articleSummary = document.getElementById('summary').value;
	var articleDate = document.getElementById('publicationDate').value;

	var params = 'articleId=' + escape(articleId);
	params += '&articleTitle=' + escape(articleTitle);
	params += '&articleDate=' + escape(articleDate);
	params += '&articleContent=' + escape(articleContent);
	params += '&articleSummary=' + escape(articleSummary);

	var url = 'saveChanges.php';

	// TODO: instantiate an ajax request to send this data to a PHP file
	// that will update the db

	// TODO: what should happen after the ajax request to save the article
	// changes is sent?
}
