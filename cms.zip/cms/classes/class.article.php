<?php

class article {

	private $mysqli;

	// class constructor - function that gets called whenever an instance
	// of the class is created. in this one we pass it the db connection
	// as an argument and save it as a private member variable to be used
	// later.
	function __construct(mysqli $mysqli) {

		$this->mysqli = $mysqli;
	}
	
	public function getArticle($articleId) {

		// TODO: query the database to get the values of the variables
		// being set in $articleArray for article with id $articleId

		$articleArray = array('title' => $articleTitle,
			'summary' => $articleSummary,
			'content' => $articleContent,
			'publicationDate' => $articleDate);

		return $articleArray;
	}
	
	public function getArticleList($maxNumArticles=1000) {

		$articleListArray = array();

		// get the most recent $maxNumArticles articles
		$query = "SELECT *
			FROM articles
			ORDER BY id DESC
			LIMIT " . $maxNumArticles;
		$articleData = $this->mysqli->query($query);

		while ($articleResults = $articleData->fetch_array()) {

			$articleId = $articleResults['id'];
			$articleDate = $articleResults['publicationDate'];
			$articleTitle = $articleResults['title'];
			$articleSummary = $articleResults['summary'];
			$articleContent = $articleResults['content'];

			$articleArray = array('id' => $articleId,
				'title' => $articleTitle,
				'summary' => $articleSummary,
				'content' => $articleContent,
				'publicationDate' => $articleDate);

			array_push($articleListArray, $articleArray);
		}

		$outputArray = array('articles' => $articleListArray,
			'totalRows' => sizeof($articleListArray));

		return $outputArray;
	}
	
	public function addArticle($articleArray) {

		// get the article details from the array
		$articleId = $articleArray['articleId'];
		$articleTitle = $articleArray['articleTitle'];
		$articleDate = $articleArray['articleDate'];
		$articleSummary = $articleArray['articleSummary'];
		$articleContent = $articleArray['articleContent'];

		// update user-entered data to prevent MySQL injection
		// http://php.net/manual/en/security.database.sql-injection.php
		$articleTitle = $this->mysqli->real_escape_string($articleTitle);
		$articleDate = $this->mysqli->real_escape_string($articleDate);
		$articleSummary = $this->mysqli->real_escape_string($articleSummary);
		$articleContent = $this->mysqli->real_escape_string($articleContent);

		// TODO: perform an INSERT query to the db to add this article
		// to the articles table
	}

	// this function takes in an array with the article info and updates
	// the entry with id = $articleId in the database
	public function updateArticle($articleArray) {

		$articleId = $articleArray['articleId'];
		$articleTitle = $articleArray['articleTitle'];
		$articleDate = $articleArray['articleDate'];
		$articleSummary = $articleArray['articleSummary'];
		$articleContent = $articleArray['articleContent'];

		// update user-entered data to prevent MySQL injection
		// http://php.net/manual/en/security.database.sql-injection.php
		$articleTitle = $this->mysqli->real_escape_string($articleTitle);
		$articleDate = $this->mysqli->real_escape_string($articleDate);
		$articleSummary = $this->mysqli->real_escape_string($articleSummary);
		$articleContent = $this->mysqli->real_escape_string($articleContent);

		// TODO: perform an UPDATE query to the db to update the values
		// of the columns for the article with id = $articleId
	}

	// this function deletes the article with id = $articleId from the db
	public function deleteArticle($articleId) {

		$query = "DELETE FROM articles
			WHERE id = " . $articleId;
		$this->mysqli->query($query);
	}
}

?>
