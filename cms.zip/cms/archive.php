<?php

require( "conn.php" );
require("classes/class.article.php");

$pageTitle = 'Article Archive';

$articleObject = new article($mysqli);
$articleInfoArray = $articleObject->getArticleList();
$articleArray = $articleInfoArray['articles'];
$numArticles = $articleInfoArray['totalRows'];

$articleList = '';

foreach ($articleArray as $article) {

	// strtotime converts the date (stored as YYYY-MM-DD in the db)
	// to a unix timestamp, and then date gives it a pretty format.
	$displayDate = date('j F Y', strtotime($article['publicationDate']));

	$articleList .= '<li><h2>';
	$articleList .= '<span class="pubDate">' . $displayDate . '</span>';
	$articleList .= '<a href="viewArticle.php?articleId=' . $article['id'] . '">' . htmlspecialchars($article['title']) . '</a>';
        $articleList .= '</h2>';
        $articleList .= '<p class="summary">' . htmlspecialchars($article['summary']) . '</p>';
        $articleList .= '</li>';
}     

?>

<!DOCTYPE html>
<html lang="en">
<head>
  
	<title><?php echo htmlspecialchars($pageTitle); ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
    
</head>
<body>
  
	<div id="container">

	<a href="."><img id="logo" src="images/logo.jpg" alt="My CMS" /></a>
      
	<h1>Article Archive</h1>

	<ul id="headlines" class="archive">
	
	<?php echo $articleList; ?>
	
	</ul>

	<p><?php echo $numArticles; ?> article<?php echo ( $numArticles != 1 ) ? 's' : ''; ?> in total.</p>

	<p><a href="index.php">Return to Homepage</a></p>
      
	<div id="footer">
		My CMS &copy; 2016. All rights reserved. <a href="admin.php">Site Admin</a>
	</div>

	</div>
</body>
</html>

      

      
