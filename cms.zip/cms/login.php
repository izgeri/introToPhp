<?php 

require("conn.php");

$pageTitle = "Admin Login";

?>

<!DOCTYPE html>
<html lang="en">
<head>
  
	<title><?php echo htmlspecialchars($pageTitle); ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<script src="js/scripts.js" type="text/javascript"></script>
    
</head>
<body>
  
	<div id="container">

	<a href="."><img id="logo" src="images/logo.jpg" alt="My CMS" /></a>

        <input type="hidden" name="login" value="true" />

        <ul>

          <li>
            <label for="username">Username</label>
            <input type="text" name="username" id="username" placeholder="Your admin username" required autofocus maxlength="20" />
          </li>

          <li>
            <label for="password">Password</label>
            <input type="password" name="password" id="password" placeholder="Your admin password" required maxlength="20" />
          </li>

        </ul>

        <div class="buttons">
          <input type="submit" name="login" value="Login" onclick="checkLogin();" />
        </div>
        
        <div id="loginErrorMessage" class="errorMessage"></div>
      
      <div id="footer">
		My CMS &copy; 2016. All rights reserved. <a href="admin.php">Site Admin</a>
	</div>

	</div>
</body>
</html>