<?php 

require("conn.php");

$username = $_POST['username'];
$password = $_POST['password'];

$successfulLogin = 0;
$query = "SELECT id
	FROM adminUsers
	WHERE username = '" . $mysqli->real_escape_string($username) . "'
	AND password = '" . $mysqli->real_escape_string(SHA1($password)) . "'
	LIMIT 1";
$result = $mysqli->query($query);

if ($result->num_rows > 0) {
	
	$successfulLogin = 1;
	$_SESSION['session_locked'] = 0;
	setcookie("username", $_POST['username'], false, "/", false);
}

echo $successfulLogin;

?>

