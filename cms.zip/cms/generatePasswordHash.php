<?php

$password = 'adminPass';
$hashPassword = SHA1($password);
echo $hashPassword;

?>
