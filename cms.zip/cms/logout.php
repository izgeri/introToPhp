<?php

session_start();
require( "conn.php" );

setcookie("username", '', false, "/", false);
session_unset();
session_destroy();

$pageTitle = 'Admin Logout';
$pageContent = '<p><em>You have been logged out of the admin section.<em></p>';

?>

<!DOCTYPE html>
<html lang="en">
<head>
  
	<title><?php echo htmlspecialchars($pageTitle); ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
    
</head>
<body>
  
	<div id="container">

	<a href="."><img id="logo" src="images/logo.jpg" alt="My CMS" /></a>
      
	<?php echo $pageContent; ?>

	<p><a href="index.php">Return to Homepage</a></p>
      
	<div id="footer">
		My CMS &copy; 2016. All rights reserved. <a href="admin.php">Site Admin</a>
	</div>

	</div>
</body>
</html>  
