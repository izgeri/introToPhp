<?php

$dbhost = 'localhost';
$dbport = '3308';
$dbuser = 'demo';
$dbpass = 'demopass';
$selectdb = 'cms';

// set timezone
date_default_timezone_set('America/New_York');

// turn error displaying on in dev
ini_set( "display_errors", true );

$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $selectdb, $dbport);

if ($mysqli->connect_error) {
	
	die('Connect Error (' . $mysqli->connect_errno . ') '
		. $mysqli->connect_error);
}

function handleException($exception) {
	
	echo "Sorry, a problem occurred. Please try later.";
	error_log($exception->getMessage());
}

set_exception_handler('handleException');

?>
