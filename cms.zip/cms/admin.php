<?php

session_start();

require( "conn.php" );

$username = isset( $_COOKIE['username'] ) ? $_COOKIE['username'] : "";
if (!$username) {
	header("Refresh: 0; URL=login.php");
	echo "You must be logged in to do that.<br>";
	echo "You are being redirected to the login page.<br>";
	echo "If you're not there in 5 seconds, " .
		"<a href=\"login.php\">click here</a>";
	die();
}

require("classes/class.article.php");

$pageTitle = 'All Articles';

$articleObject = new article($mysqli);
$articleInfoArray = $articleObject->getArticleList();
$articleList = $articleInfoArray['articles'];
$numArticles = $articleInfoArray['totalRows'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
  
	<title><?php echo htmlspecialchars($pageTitle); ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<script src="js/scripts.js" type="text/javascript"></script>

</head>
<body>
  
	<div id="container">

	<a href="."><img id="logo" src="images/logo.jpg" alt="My CMS" /></a>
      
	<div id="adminHeader">
        	<h2>My CMS Admin</h2>
        	<p>You are logged in as <b><?php echo htmlspecialchars($_COOKIE['username']); ?></b>. <a class="hoverHand" onclick="logout();">log out</a></p>
	</div>

	<h1>All Articles</h1>

	<table>
          <tr>
            <th>Publication Date</th>
            <th>Article</th>
          </tr>

	  <?php foreach ($articleList as $article) { ?>

          <tr onclick="location='editArticle.php?articleId=<?php echo $article['id']; ?>'">
            <td><?php echo date('j M Y', strtotime($article['publicationDate'])); ?></td>
            <td><?php echo $article['title']; ?></td>
          </tr>

	  <?php } ?>

	</table>

	<p><?php echo $numArticles; ?> article<?php echo ( $numArticles != 1 ) ? 's' : '' ?> in total.</p>

	<p><a href="editArticle.php">Add a New Article</a></p>
      
	<div id="footer">
		My CMS &copy; 2016. All rights reserved. <a href="admin.php">Site Admin</a>
	</div>

	</div>
</body>
</html>
