<?php

require( "conn.php" );
require("classes/class.article.php");

$articleObject = new article($mysqli);
$articleInfoArray = $articleObject->getArticleList(5);
$articleArray = $articleInfoArray['articles'];
$totalRows = $articleInfoArray['totalRows'];
$pageTitle = "Home";

?>

<!DOCTYPE html>
<html lang="en">
<head>
  
	<title><?php echo htmlspecialchars($pageTitle); ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
    
</head>
<body>
  
	<div id="container">

	<a href="."><img id="logo" src="images/logo.jpg" alt="My CMS" /></a>
      
	<ul id="headlines">
      
	<?php 
		foreach ($articleArray as $article) {
      
			?>
			<li>
			<h2>
			<span class="pubDate"><?php echo date('j F', strtotime($article['publicationDate'])); ?></span>
			<a href="viewArticle.php?articleId=<?php echo $article['id']; ?>"><?php echo htmlspecialchars($article['title']); ?></a>
			</h2>
			<p class="summary"><?php echo htmlspecialchars( $article['summary'] ); ?></p>
			</li>
			<?php
      	
		}
	?>
	
	</ul>

	<p><a href="archive.php">Article Archive</a></p>
      
	<div id="footer">
		My CMS &copy; 2016. All rights reserved. <a href="admin.php">Site Admin</a>
	</div>

	</div>
</body>
</html>

      
