<?php

$dbhost = 'localhost';
$dbport = '8889';
$dbuser = 'demo';
$dbpass = 'demopass';
$selectdb = 'introToPhp';

$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $selectdb, $dbport);

if ($mysqli->connect_error) {
	
	die('Connect Error (' . $mysqli->connect_errno . ') '
		. $mysqli->connect_error);
}

?>