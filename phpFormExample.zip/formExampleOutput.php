<?php 

$name = $_POST['name'];
$message = $_POST['message'];

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
 "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Basic PHP form example</title>

<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="formOutputDisplay">
<h3>Thanks, <?php echo $name; ?>!</h3> We've received your message.
For your convenience, your message is displayed below.<br /><br />
<b>Message:</b><br />
<span id="formMessage"><?php echo $message; ?></span>
</div>

</body>
</html>
